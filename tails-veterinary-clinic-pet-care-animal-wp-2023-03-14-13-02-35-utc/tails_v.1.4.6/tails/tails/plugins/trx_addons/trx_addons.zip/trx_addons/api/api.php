<?php
/**
 * ThemeREX Addons API
 *
 * @package WordPress
 * @subpackage ThemeREX Addons
 * @since v1.1
 */


// Check if plugin 'Gutenberg' is installed and activated
if ( ! function_exists( 'trx_addons_exists_gutenberg' ) ) {
    function trx_addons_exists_gutenberg() {
        return function_exists( 'register_block_type' );  // && function_exists( 'the_gutenberg_project' )
    }
}

// Check if current page is a PageBuilder preview mode
if ( ! function_exists( 'trx_addons_is_preview' ) ) {
    function trx_addons_is_preview( $builder = 'any' ) {
        return ( in_array( $builder, array( 'any', 'elm', 'elementor' ) ) && function_exists( 'trx_addons_elm_is_preview' ) && trx_addons_elm_is_preview() )
            ||
            ( in_array( $builder, array( 'any', 'gb', 'gutenberg' ) ) && function_exists( 'trx_addons_gutenberg_is_preview' ) && trx_addons_gutenberg_is_preview() );
    }
}